from flask import Flask, request, jsonify
import requests
import json

app = Flask(__name__)

OLLAMA_URL = "http://localhost:11434/api/generate"


model_map = {
    ("eng", "pl"): "gemma:2b",
    ("pl", "eng"): "gemma:2b",
    ("eng", "fr"): "mistral:7b",
    ("fr", "eng"): "mistral:7b",
    ("pl", "fr"): "mwiewior/bielik:latest",
    ("fr", "pl"): "mwiewior/bielik:latest",
}

def translate(source_lang, target_lang, text):
    model = model_map.get((source_lang, target_lang))
    if not model:
        return None, f"Brak modelu dla {source_lang} -> {target_lang}"

    prompt = (
        f"Act as a professional translator. Translate the text from {source_lang} to {target_lang}. "
        f"Output ONLY the translated text with no additional commentary.\n\n{text}"
    )

    payload = {
        "model": model,
        "prompt": prompt
    }

    try:
        response = requests.post(OLLAMA_URL, json=payload, stream=True)
    except requests.exceptions.ConnectionError:
        return None, "Nie można połączyć się z Ollama."

    translated_text = ""
    for line in response.iter_lines():
        if line:
            try:
                obj = json.loads(line.decode("utf-8"))
                translated_text += obj.get("response", "")
            except json.JSONDecodeError:
                pass

    return translated_text.strip(), None

@app.route("/translate", methods=["POST"])
def api_translate():
    data = request.json
    if not data:
        return jsonify({"error": "Brak danych JSON"}), 400

    source = data.get("source_lang")
    target = data.get("target_lang")
    text = data.get("text")

    if not all([source, target, text]):
        return jsonify({"error": "Brakuje source_lang, target_lang lub text"}), 400

    translated, error = translate(source, target, text)
    if error:
        return jsonify({"error": error}), 500

    return jsonify({"translation": translated})

if __name__ == "__main__":
    app.run(port=5000)
