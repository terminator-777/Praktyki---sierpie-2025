import sys
import json
import pyperclip
import requests

OLLAMA_URL = "http://localhost:11434/api/generate"

model_map = {
    ("eng", "pl"): "gemma:2b",       
    ("pl", "eng"): "gemma:2b",       
    ("eng", "fr"): "mistral:7b",     
    ("fr", "eng"): "mistral:7b",     
    ("pl", "fr"): "mwiewior/bielik:latest",       
    ("fr", "pl"): "mwiewior/bielik:latest",       
}

def translate(source_lang, target_lang, text):
    model = model_map.get((source_lang, target_lang))
    if not model:
        raise ValueError(f"Brak modelu dla {source_lang} -> {target_lang}")

    prompt = (
    f"Act as a professional translator. Translate the text from {source_lang} to {target_lang}. "
    f"Output ONLY the translated text with no additional commentary.\n\n{text}"
)


    payload = {
        "model": model,
        "prompt": prompt
    }

    try:
        response = requests.post(OLLAMA_URL, json=payload, stream=True)
    except requests.exceptions.ConnectionError:
        print("Błąd: Nie można połączyć się z Ollama. Czy serwer działa?")
        sys.exit(1)

    output = ""
    for line in response.iter_lines():
        if line:
            try:
                obj = json.loads(line.decode("utf-8"))
                output += obj.get("response", "")
            except json.JSONDecodeError:
                pass

    return output.strip()

#Tryb terminalowy
if len(sys.argv) > 1 and sys.argv[1] != "server":
    langs = sys.argv[1].split(":")
    if len(langs) != 2:
        print("Błędny format. Poprawny przykład: python translate.py eng:pl")
        sys.exit(1)

    source_lang, target_lang = langs
    text = pyperclip.paste()

    if not text.strip():
        print("❌ Schowek jest pusty. Skopiuj tekst do przetłumaczenia i spróbuj ponownie.")
        sys.exit(1)

    translated = translate(source_lang, target_lang, text)

    print("\n=== Tłumaczenie ===\n")
    print(translated)
    sys.exit(0)
