import os
import yt_dlp
import whisper
from langdetect import detect
from googletrans import Translator
from gtts import gTTS

# --- 1. Pobranie audio z YouTube ---
def download_audio(url, outdir="downloads"):
    os.makedirs(outdir, exist_ok=True)
    ydl_opts = {
        'format': 'bestaudio/best',
        'outtmpl': f'{outdir}/%(title)s.%(ext)s',
        'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3'}],
    }
    with yt_dlp.YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=True)
        filename = f"{outdir}/{info['title']}.mp3"
    return filename

# --- 2. Transkrypcja audio (Whisper) ---
def transcribe_audio(file_path):
    model = whisper.load_model("small")  # modele: tiny, base, small, medium, large
    result = model.transcribe(file_path)
    return result["text"]

# --- 3. Detekcja języka ---
def detect_language(text):
    return detect(text)

# --- 4. Tłumaczenie ---
def translate_text(text, target_lang="pl"):
    translator = Translator()
    translated = translator.translate(text, dest=target_lang)
    return translated.text

# --- 5. Generowanie mowy (TTS) ---
def text_to_speech(text, out_path="output.mp3", lang="pl"):
    tts = gTTS(text=text, lang=lang)
    tts.save(out_path)
    return out_path

# --- 6. Pipeline ---
def main():
    youtube_url = input("Podaj link do YouTube: ")
    
    print("⏬ Pobieranie audio...")
    audio_file = download_audio(youtube_url)
    
    print("📝 Transkrypcja (Whisper)...")
    transcript = transcribe_audio(audio_file)
    print("Oryginalny tekst:", transcript[:200], "...")
    
    print("🌍 Wykrywanie języka...")
    lang = detect_language(transcript)
    print(f"Zidentyfikowany język: {lang}")
    
    print("🔄 Tłumaczenie...")
    translated_text = translate_text(transcript, target_lang="pl")
    print("Przetłumaczony tekst:", translated_text[:200], "...")
    
    print("🔊 Generowanie mowy...")
    final_audio = text_to_speech(translated_text, "final_output.mp3", lang="pl")
    print(f"Gotowe! Plik zapisany jako: {final_audio}")

if __name__ == "__main__":
    main()
