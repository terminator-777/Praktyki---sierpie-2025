# simple_local_server.py
import http.server
import socketserver
import webbrowser

PORT = 8000
Handler = http.server.SimpleHTTPRequestHandler

# Otwórz przeglądarkę automatycznie
webbrowser.open(f'http://localhost:{PORT}')

with socketserver.TCPServer(('', PORT), Handler) as httpd:
    print(f"Serwer lokalny uruchomiony na porcie {PORT}")
    print(f"Strona powinna otworzyć się automatycznie w przeglądarce: http://localhost:{PORT}")
    httpd.serve_forever()
